"""
Application factory for the HR system (محدّث – إصلاح تكرار الإجازات).
"""

from flask import Flask, redirect, url_for

from msd.database.connection import get_conn, close_db

# Blueprints (Auth)
from msd.auth.routes import auth_bp

# صفحات (واجهات)
from msd.pages.vacations_page import vacations_page_bp
from msd.pages.absences_page import absences_page_bp
from msd.pages.department_head_page import department_head_page_bp
from msd.pages.manager_page import manager_page_bp
from msd.pages.employees_page import employees_console_bp
from msd.pages.departments_page import departments_bp

# APIs أخرى
from msd.absences.routes_absences import absences_api
from msd.manager.routes_manager import manager_api
from msd.service_requests.routes import service_requests_api
from msd.service_requests.views import service_requests_pages
from msd.backup.routes import backup_bp
from msd.api.vacation_types_api import vacation_types_api_bp

# NEW imports
from msd.api.employees_api import employees_api_bp
from msd.manager.departments_api import departments_api_bp

# API الجديدة للإجازات (مُعاد بناؤها)
from msd.api.vacations_api import vacations_api_bp, init_vacations_api

# استخدم LoginManager الموحد من msd.extensions (لا تنشئ واحداً جديداً)
from msd.extensions import login_manager

try:
    from config import Config
except ImportError:
    class Config:
        SECRET_KEY = "dev-secret"
        DATABASE_PATH = "employees.db"


def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates")
    app.config.from_object(Config)

    init_extensions(app)
    register_blueprints(app)
    register_public_routes(app)
    register_error_handlers(app)

    app.teardown_appcontext(close_db)
    return app


def init_extensions(app: Flask):
    # تفعيل LoginManager الموحّد
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id: str):
        from msd.auth.models import User
        try:
            with get_conn() as conn:
                cur = conn.cursor()
                cur.execute(
                    "SELECT id, username, role, department_id, telegram_chat_id "
                    "FROM users WHERE id=?",
                    (user_id,)
                )
                row = cur.fetchone()
            if row:
                return User(
                    id=row[0],
                    username=row[1],
                    role=row[2],
                    department_id=row[3],
                    telegram_chat_id=row[4]
                )
        except Exception as e:
            print("load_user error:", e)
        return None


def register_blueprints(app: Flask):
    # Auth
    app.register_blueprint(auth_bp)

    # APIs
    app.register_blueprint(vacations_api_bp)
    app.register_blueprint(absences_api, url_prefix="/api/v1")
    app.register_blueprint(manager_api, url_prefix="/api/v1")
    app.register_blueprint(service_requests_api, url_prefix="/api/v1")
    app.register_blueprint(vacation_types_api_bp)
    app.register_blueprint(employees_api_bp)
    app.register_blueprint(departments_api_bp)

    # Pages
    app.register_blueprint(vacations_page_bp)
    app.register_blueprint(absences_page_bp)
    app.register_blueprint(department_head_page_bp)
    app.register_blueprint(manager_page_bp)
    app.register_blueprint(employees_console_bp)
    app.register_blueprint(service_requests_pages)
    app.register_blueprint(departments_bp)
    app.register_blueprint(backup_bp)

    # تهيئة جداول history الخاصة بالإجازات
    init_vacations_api(app)


def register_public_routes(app: Flask):
    @app.route("/")
    def index():
        from flask_login import current_user
        if current_user.is_authenticated:
            if current_user.role in ("manager", "admin"):
                return redirect(url_for("manager_page_bp.manager_portal"))
            if current_user.role == "department_head":
                return redirect(url_for("department_head_page_bp.dept_head_page"))
            return redirect(url_for("vacations_page_bp.vacations_page"))
        return redirect(url_for("auth.login"))

    @app.route("/home")
    def home_alias():
        return index()

    @app.route("/favicon.ico")
    def favicon():
        return ("", 204)

    @app.route("/health")
    def health():
        return {"status": "ok"}, 200


def register_error_handlers(app: Flask):
    @app.errorhandler(404)
    def not_found(e):
        return "الصفحة غير موجودة", 404

    @app.errorhandler(403)
    def forbidden(e):
        return "غير مسموح بالوصول", 403