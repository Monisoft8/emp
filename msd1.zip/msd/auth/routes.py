from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_user, logout_user, login_required, current_user
import sqlite3
from msd.database.connection import get_conn

# نحافظ على الاسم الذي يعتمد عليه create_app
auth_bp = Blueprint("auth", __name__)

# نموذج جلسة بسيط (Flask-Login سيعيد User من user_loader في الطلبات اللاحقة)
class AuthUser:
    def __init__(self, r):
        self.id = r["id"]
        self.username = r["username"]
        self.role = r["role"]
        self.department_id = r["department_id"]
    @property
    def is_authenticated(self): return True
    @property
    def is_active(self): return True
    @property
    def is_anonymous(self): return False
    def get_id(self): return str(self.id)

def _fetch_user_by_username(username: str):
    with get_conn() as conn:
        conn.row_factory = sqlite3.Row
        return conn.execute(
            "SELECT id, username, password_hash, role, department_id FROM users WHERE username=?",
            (username,)
        ).fetchone()

def _password_ok(stored_hash: str, given_password: str) -> bool:
    """
    يدعم hash عبر werkzeug وكذلك نص عادي موجود مسبقاً.
    """
    if not stored_hash or not given_password:
        return False
    s = str(stored_hash)
    # بادئات شائعة لـ werkzeug
    KNOWN_PREFIXES = ("pbkdf2:", "scrypt:", "argon2:", "sha256$", "pbkdf2_sha256:")
    try:
        if s.startswith(KNOWN_PREFIXES):
            from werkzeug.security import check_password_hash
            return check_password_hash(s, given_password)
        # خلاف ذلك نعتبره نصاً عادياً
        return s == given_password
    except Exception:
        # في أي خطأ نحاول مقارنة نصية مباشرة
        return s == given_password

def _role_home(role: str):
    if role in ("manager", "admin"):
        return "/manager"
    if role == "department_head":
        return "/dept-head"
    return "/vacations"

def _next_allowed_for_role(next_url: str, role: str) -> bool:
    if not next_url or not next_url.startswith("/"):
        return False
    if role in ("manager", "admin"):
        return True
    if role == "department_head":
        # منع صفحات المدير
        if next_url.startswith("/manager") or next_url.startswith("/api/v1/manager"):
            return False
        return True
    return False

@auth_bp.route("/", methods=["GET"])
def index():
    if current_user.is_authenticated:
        return redirect(_role_home(getattr(current_user, "role", "")))
    return redirect(url_for("auth.login"))

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")

    # POST: قبول form أو JSON
    def get_field(name):
        if request.is_json:
            js = request.get_json(silent=True) or {}
            return js.get(name)
        return request.form.get(name)

    username = (get_field("username") or "").strip()
    password = (get_field("password") or "").strip()
    next_url = request.args.get("next") or get_field("next")

    row = _fetch_user_by_username(username)
    if not row or not _password_ok(row["password_hash"], password):
        if request.is_json:
            return jsonify({"error": "بيانات غير صحيحة"}), 401
        flash("بيانات الدخول غير صحيحة", "danger")
        return redirect(url_for("auth.login"))

    # ترقية admin تلقائياً إن لم يكن admin/manager
    if username == "admin" and row["role"] not in ("manager", "admin"):
        try:
            with get_conn() as conn:
                conn.execute("UPDATE users SET role='admin' WHERE id=?", (row["id"],))
                conn.commit()
            # حدّث الدور في الذاكرة
            row = dict(row)
            row["role"] = "admin"
            row = sqlite3.Row(sqlite3.Connection(":memory:"), list(row.keys()), list(row.values()))
        except Exception:
            pass

    user = AuthUser(row)
    login_user(user)

    # توجيه آمن حسب الدور
    role = getattr(user, "role", "")
    if _next_allowed_for_role(next_url, role):
        return redirect(next_url)
    return redirect(_role_home(role))

@auth_bp.route("/logout", methods=["GET"])
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))

@auth_bp.route("/dept-head", methods=["GET"])
@login_required
def dept_head_page():
    role = getattr(current_user, "role", "")
    if role == "department_head":
        return render_template("department_head.html")
    if role in ("manager", "admin"):
        return redirect("/manager")
    return redirect(url_for("auth.login"))