from flask_login import current_user
from functools import wraps
from flask import abort

def roles_required(*roles):
    """
    يسمح فقط للأدوار المحددة بالوصول.
    ملاحظة: الدور 'admin' يعتبر Superuser ويسمح له بكل الصفحات تلقائياً.
    """
    allowed = set(roles)

    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                # اترك @login_required يتكفّل بالتوجيه، أو أعد 401 هنا
                abort(401)
            # admin مسموح له دائماً
            if getattr(current_user, "role", None) == "admin":
                return f(*args, **kwargs)
            if getattr(current_user, "role", None) not in allowed:
                abort(403)
            return f(*args, **kwargs)
        return wrapped
    return decorator