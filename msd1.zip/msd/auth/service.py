from msd.database.connection import get_conn
from werkzeug.security import check_password_hash
from msd.auth.models import User

def verify_credentials(username: str, password: str):
    """
    يتحقق من صحة بيانات الدخول.
    يستخدم فقط werkzeug (بدون passlib) لتجنب مشاكل bcrypt/passlib.
    """
    if not username or not password:
        return None
    with get_conn() as conn:
        # اجلب كل الأعمدة المحتملة (مرونة)
        cols = {r[1] for r in conn.execute("PRAGMA table_info(users)")}
        sel = ["id","username","role","password_hash"]
        if "department_id" in cols: sel.append("department_id")
        if "telegram_chat_id" in cols: sel.append("telegram_chat_id")
        if "employee_id" in cols: sel.append("employee_id")
        sql = f"SELECT {', '.join(sel)} FROM users WHERE username=?"
        row = conn.execute(sql,(username,)).fetchone()
        if not row:
            return None
        data = dict(zip(sel, row))
        stored_hash = data.get("password_hash") or ""
        # في حالة كان الحقل فارغ يمكن (مؤقتاً) رفض مباشرة
        if not stored_hash or not check_password_hash(stored_hash, password):
            return None
        return User(
            id=data["id"],
            username=data["username"],
            role=data["role"],
            department_id=data.get("department_id"),
            telegram_chat_id=data.get("telegram_chat_id"),
            employee_id=data.get("employee_id"),
        )