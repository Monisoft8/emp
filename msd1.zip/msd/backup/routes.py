import os
from flask import Blueprint, send_file
from flask_login import login_required, current_user

backup_bp = Blueprint("backup_bp", __name__)

@backup_bp.get("/backup/database")
@login_required
def download_database():
    if current_user.role not in ("manager", "admin"):
        return "غير مسموح", 403
    db_path = os.getenv("DATABASE_PATH", "employees.db")
    if not os.path.exists(db_path):
        return "قاعدة البيانات غير موجودة", 404
    return send_file(db_path, as_attachment=True, download_name="employees_backup.sqlite")