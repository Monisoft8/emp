from msd.database.connection import get_conn

def consume_balance(emp_id, type_code, days):
    if type_code == "ANNUAL":
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT annual_balance FROM employees WHERE id=?", (emp_id,))
            bal = cur.fetchone()
            if not bal or bal["annual_balance"] < days:
                raise ValueError("رصيد سنوي غير كافٍ")
            cur.execute("UPDATE employees SET annual_balance = annual_balance - ? WHERE id=?",
                        (days, emp_id))
            conn.commit()
    elif type_code == "EMERGENCY":
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute("SELECT emergency_balance FROM employees WHERE id=?", (emp_id,))
            bal = cur.fetchone()
            if not bal or bal["emergency_balance"] < days:
                raise ValueError("رصيد طارئ غير كافٍ")
            cur.execute("UPDATE employees SET emergency_balance = emergency_balance - ? WHERE id=?",
                        (days, emp_id))
            conn.commit()
    else:
        # لا يؤثر على الرصيد
        return

def restore_balance(emp_id, type_code, days):
    if type_code in ("ANNUAL", "EMERGENCY"):
        col = "annual_balance" if type_code == "ANNUAL" else "emergency_balance"
        with get_conn() as conn:
            cur = conn.cursor()
            cur.execute(f"UPDATE employees SET {col} = {col} + ? WHERE id=?", (days, emp_id))
            conn.commit()