from flask import Blueprint, render_template
from flask_login import login_required
from msd.utils.security import role_required

dashboard_bp = Blueprint("dashboard", __name__)

@dashboard_bp.route("/manager")
@login_required
@role_required("manager")
def manager_dashboard():
    # يمكنك لاحقاً إضافة استعلامات قاعدة بيانات لتجميع إحصاءات المدير
    return render_template("manager_dashboard.html")

@dashboard_bp.route("/dept")
@login_required
@role_required("dept_head")
def dept_dashboard():
    # يمكنك لاحقاً إضافة استعلامات قاعدة بيانات لتجميع إحصاءات القسم
    return render_template("dept_dashboard.html")