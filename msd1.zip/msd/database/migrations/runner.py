import importlib
from msd.database.connection import get_conn

# أضفنا الهجرة v005 في النهاية
MIGRATIONS = [
    "msd.database.migrations.v001_add_columns",
    "msd.database.migrations.v002_create_vacation_requests",
    "msd.database.migrations.v003_status_unify_placeholder",
    "msd.database.migrations.v004_add_department_id_to_users",
    "msd.database.migrations.v005_rejection_and_history",
    "msd.database.migrations.v006_add_spouse_death_type",
    "msd.database.migrations.v007_rename_death_spouse",
    "msd.database.migrations.v008_absences_enhancements",
    "msd.database.migrations.v009_add_telegram_and_dept_to_users",
    "msd.database.migrations.v010_add_user_id_to_employees",
    "msd.database.migrations.v011_create_audit_log",
    "msd.database.migrations.v012_add_head_user_to_departments",
    "msd.database.migrations.v013_add_range_to_absences",
    "msd.database.migrations.v014_absences_indexes",
    "msd.database.migrations.v016_scripts_migrate_full_hr_schema"
]

def _ensure_meta():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS migration_meta(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT UNIQUE NOT NULL,
              applied_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()

def _was_applied(name):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT 1 FROM migration_meta WHERE name=?", (name,))
        return cur.fetchone() is not None

def _mark_applied(name):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO migration_meta(name) VALUES(?)", (name,))
        conn.commit()

def run_all_migrations():
    _ensure_meta()
    for path in MIGRATIONS:
        name = path.split(".")[-1]
        if _was_applied(name):
            continue
        module = importlib.import_module(path)
        # كل الهجرات تستخدم up() بدون معاملات
        module.up()
        _mark_applied(name)