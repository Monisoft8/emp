"""
الهجرة V001: إضافة أعمدة جديدة للموظفين (annual_balance, emergency_balance, gender)
وإنشاء جدول vacation_types (إن لم يكن موجوداً) + فهارس بسيطة.
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # تأكد من وجود أعمدة
        cur.execute("PRAGMA table_info(employees)")
        cols = {r["name"] for r in cur.fetchall()}

        if "annual_balance" not in cols:
            cur.execute("ALTER TABLE employees ADD COLUMN annual_balance REAL DEFAULT 0")
        if "emergency_balance" not in cols:
            # محاولة أخذ الرصيد القديم إن وجد
            if "emergency_vacation_balance" in cols:
                cur.execute("ALTER TABLE employees ADD COLUMN emergency_balance INTEGER DEFAULT 12")
                cur.execute("UPDATE employees SET emergency_balance = emergency_vacation_balance WHERE emergency_vacation_balance IS NOT NULL")
            else:
                cur.execute("ALTER TABLE employees ADD COLUMN emergency_balance INTEGER DEFAULT 12")
        if "gender" not in cols:
            cur.execute("ALTER TABLE employees ADD COLUMN gender TEXT")

        if "vacation_types" not in _tables(cur):
            cur.execute("""
                CREATE TABLE vacation_types(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  code TEXT UNIQUE NOT NULL,
                  name_ar TEXT NOT NULL,
                  fixed_duration INTEGER,
                  max_per_request INTEGER,
                  affects_annual_balance INTEGER DEFAULT 0,
                  affects_emergency_balance INTEGER DEFAULT 0,
                  approval_flow TEXT DEFAULT 'dept_then_manager',
                  requires_relation INTEGER DEFAULT 0
                )
            """)

        # فهرس للبحث السريع عن الإجازات لاحقاً (إن وجد vacations قديم)
        if "vacations" in _tables(cur):
            cur.execute("CREATE INDEX IF NOT EXISTS idx_vacations_emp ON vacations(employee_id)")
        conn.commit()

def _tables(cur):
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    return {r["name"] for r in cur.fetchall()}