"""
الهجرة V002 (متوافقة مع مخططك الحالي):
- إذا لم يوجد vacation_requests يتم إنشاؤه.
- نسخ البيانات من جدول vacations الحالي (الذي يحتوي workflow_state).
- تجاهل النسخ إذا كان الجدول الجديد فيه بيانات مسبقاً.
"""

from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()

        # إنشاء جدول vacation_requests إن لم يكن موجوداً
        cur.execute("""
            CREATE TABLE IF NOT EXISTS vacation_requests(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              employee_id INTEGER NOT NULL,
              type_code TEXT NOT NULL,
              relation TEXT,
              start_date TEXT NOT NULL,
              end_date TEXT NOT NULL,
              requested_days INTEGER NOT NULL,
              status TEXT NOT NULL,
              dept_decision_at TEXT,
              dept_decision_by INTEGER,
              manager_decision_at TEXT,
              manager_decision_by INTEGER,
              notes TEXT,
              created_at TEXT DEFAULT CURRENT_TIMESTAMP,
              FOREIGN KEY(employee_id) REFERENCES employees(id)
            )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_vreq_emp ON vacation_requests(employee_id)")

        # هل توجد بيانات أصلاً في vacation_requests؟ إذا نعم لا نعيد النسخ
        cur.execute("SELECT COUNT(*) FROM vacation_requests")
        if cur.fetchone()[0] > 0:
            print("[v002] vacation_requests يحتوي بيانات – تخطي النسخ.")
            conn.commit()
            return

        # هل يوجد جدول vacations بالشكل المتوقع؟
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='vacations'")
        if not cur.fetchone():
            print("[v002] لا يوجد جدول vacations – لا توجد بيانات لنسخها.")
            conn.commit()
            return

        # تحقق الأعمدة الأساسية في vacations
        cur.execute("PRAGMA table_info(vacations)")
        cols = {r[1] for r in cur.fetchall()}
        required = {"employee_id", "type_code", "start_date", "end_date", "duration", "workflow_state"}
        if not required.issubset(cols):
            print(f"[v002] جدول vacations لا يحتوي الأعمدة المتوقعة: {required - cols} – سيتم الاكتفاء بإنشاء الجدول الجديد.")
            conn.commit()
            return

        # نسخ البيانات
        copy_sql = """
            INSERT INTO vacation_requests
              (employee_id, type_code, relation, start_date, end_date,
               requested_days, status,
               dept_decision_at, dept_decision_by,
               manager_decision_at, manager_decision_by,
               notes, created_at)
            SELECT
              employee_id,
              type_code,
              relation,
              start_date,
              end_date,
              duration AS requested_days,
              workflow_state AS status,
              dept_decided_at AS dept_decision_at,
              dept_actor_id  AS dept_decision_by,
              manager_decided_at AS manager_decision_at,
              manager_actor_id  AS manager_decision_by,
              notes,
              created_at
            FROM vacations
        """
        cur.execute(copy_sql)
        inserted = cur.rowcount
        conn.commit()
        print(f"[v002] تم إدراج {inserted} صفاً في vacation_requests من vacations.")