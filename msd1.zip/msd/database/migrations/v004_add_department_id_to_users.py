"""
الهجرة V004:
- إضافة العمود department_id إلى جدول users إذا كان مفقوداً.
"""

from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # تأكد أن الجدول موجود
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        if not cur.fetchone():
            # لم يتم إنشاء users بعد (سيتم إنشاؤه لاحقاً عبر ensure_users_table)
            print("[v004] جدول users غير موجود - لا شيء لفعله.")
            return
        cur.execute("PRAGMA table_info(users)")
        cols = {r[1] for r in cur.fetchall()}
        if "department_id" not in cols:
            cur.execute("ALTER TABLE users ADD COLUMN department_id INTEGER")
            print("[v004] تمت إضافة العمود department_id إلى users.")
        else:
            print("[v004] العمود department_id موجود مسبقاً.")
        conn.commit()