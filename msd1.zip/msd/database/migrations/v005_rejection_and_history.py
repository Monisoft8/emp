"""
v005: إضافة عمود rejection_reason + إنشاء جدول vacation_request_history
"""

from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()

        # فحص عمود rejection_reason
        cur.execute("PRAGMA table_info(vacation_requests)")
        cols = {r[1] for r in cur.fetchall()}
        if "rejection_reason" not in cols:
            cur.execute("ALTER TABLE vacation_requests ADD COLUMN rejection_reason TEXT")

        # إنشاء جدول التاريخ
        cur.execute("""
            CREATE TABLE IF NOT EXISTS vacation_request_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                vacation_request_id INTEGER NOT NULL,
                action TEXT NOT NULL,             -- create / approve / reject / cancel / advance
                from_status TEXT,
                to_status TEXT,
                actor_role TEXT,
                actor_user_id INTEGER,
                note TEXT,
                created_at TEXT DEFAULT (datetime('now')),
                FOREIGN KEY(vacation_request_id) REFERENCES vacation_requests(id)
            )
        """)

        # فهرس
        cur.execute("""
            CREATE INDEX IF NOT EXISTS idx_vac_hist_req ON vacation_request_history (vacation_request_id)
        """)

        conn.commit()