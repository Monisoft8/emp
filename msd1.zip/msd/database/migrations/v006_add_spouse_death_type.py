"""
v006: إضافة نوع إجازة وفاة الزوج/الزوجة (DEATH_SPOUSE) مدة 130 يوم
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT OR IGNORE INTO vacation_types
            (code, name_ar, fixed_duration, max_per_request,
             affects_annual_balance, affects_emergency_balance,
             approval_flow, requires_relation)
            VALUES
            ('DEATH_SPOUSE','وفاة الزوج/الزوجة',130,130,0,0,'dept_then_manager',0)
        """)
        conn.commit()