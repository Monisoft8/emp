"""
v007: إعادة تسمية نوع وفاة الزوج/الزوجة إلى (وفاة الزوج) مع تغيير الكود من DEATH_SPOUSE إلى DEATH_HUSBAND
- تعديل الاسم العربي
- تحديث أية طلبات موجودة في vacation_requests
"""

from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # هل يوجد النوع القديم؟
        cur.execute("SELECT 1 FROM vacation_types WHERE code='DEATH_SPOUSE'")
        if cur.fetchone():
            # لا نُنشئ الجديد أولاً حتى لا يصطدم قيد UNIQUE
            # غيّر الأكواد في الطلبات
            cur.execute("""
                UPDATE vacation_requests
                   SET type_code='DEATH_HUSBAND'
                 WHERE type_code='DEATH_SPOUSE'
            """)
            # حدّث صف النوع
            cur.execute("""
                UPDATE vacation_types
                   SET code='DEATH_HUSBAND',
                       name_ar='وفاة الزوج',
                       fixed_duration=130,
                       max_per_request=130,
                       requires_relation=0
                 WHERE code='DEATH_SPOUSE'
            """)
        else:
            # إذا لم يوجد القديم نحاول إدخال الجديد (في حال لم تضف v006 أصلاً)
            cur.execute("""
                INSERT OR IGNORE INTO vacation_types
                (code, name_ar, fixed_duration, max_per_request,
                 affects_annual_balance, affects_emergency_balance,
                 approval_flow, requires_relation)
                VALUES
                ('DEATH_HUSBAND','وفاة الزوج',130,130,0,0,'dept_then_manager',0)
            """)
        conn.commit()