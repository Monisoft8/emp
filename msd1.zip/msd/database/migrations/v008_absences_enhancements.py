"""
v008: تحسينات جدول الغياب
- إضافة عمود created_at إن كان مفقوداً
- فهرس على التاريخ
- فهرس على (employee_id, date)
- قيد فريد (employee_id, date, type) للسماح بتعدد الأنواع في نفس اليوم لكن منع التكرار لنفس النوع
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # تحقق من وجود الجدول
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='absences'")
        if not cur.fetchone():
            # في حال لم يكن موجوداً ننشئه بالحد الأدنى
            cur.execute("""
                CREATE TABLE absences(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  employee_id INTEGER NOT NULL,
                  date TEXT NOT NULL,
                  type TEXT NOT NULL,
                  duration INTEGER DEFAULT 1,
                  notes TEXT,
                  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY(employee_id) REFERENCES employees(id)
                )
            """)
        else:
            # فحص الأعمدة
            cur.execute("PRAGMA table_info(absences)")
            cols = {r[1] for r in cur.fetchall()}
            if "created_at" not in cols:
                cur.execute("ALTER TABLE absences ADD COLUMN created_at TEXT DEFAULT CURRENT_TIMESTAMP")

        # فهارس
        cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_date ON absences(date)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_emp_date ON absences(employee_id, date)")

        # قيد فريد (قد يفشل إذا توجد بيانات مكررة – نتجاوز بصمت)
        try:
            cur.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_absences_unique ON absences(employee_id, date, type)")
        except Exception:
            pass

        conn.commit()