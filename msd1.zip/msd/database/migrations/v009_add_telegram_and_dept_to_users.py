"""
v009: إضافة telegram_chat_id و department_id إلى users (إن لم تكن موجودة)
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(users)")
        cols = {r[1] for r in cur.fetchall()}
        if "telegram_chat_id" not in cols:
            cur.execute("ALTER TABLE users ADD COLUMN telegram_chat_id TEXT")
        if "department_id" not in cols:
            cur.execute("ALTER TABLE users ADD COLUMN department_id INTEGER")
        # فهرس مساعد للبحث
        cur.execute("CREATE INDEX IF NOT EXISTS idx_users_role_dept ON users(role, department_id)")
        conn.commit()