"""
v010: إضافة عمود user_id لربط الموظف بالمستخدم (إن لم يكن موجوداً)
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(employees)")
        cols = {r[1] for r in cur.fetchall()}
        if "user_id" not in cols:
            cur.execute("ALTER TABLE employees ADD COLUMN user_id INTEGER")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_employees_user_id ON employees(user_id)")
        conn.commit()