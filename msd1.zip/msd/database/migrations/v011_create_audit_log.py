"""
v011: إنشاء جدول audit_log
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
          CREATE TABLE IF NOT EXISTS audit_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT,
            table_name TEXT,
            record_id INTEGER,
            changes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
          )
        """)
        cur.execute("CREATE INDEX IF NOT EXISTS idx_audit_table_record ON audit_log(table_name, record_id)")
        conn.commit()