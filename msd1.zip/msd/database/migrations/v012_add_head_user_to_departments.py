"""
v012: إضافة عمود head_user_id (إن لم يوجد) إلى جدول الأقسام وربط فهرس.
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # تأكد وجود الجدول (بأبسط شكل إن لم يكن موجوداً)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS departments(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              name TEXT UNIQUE NOT NULL,
              head_user_id INTEGER,
              head_password TEXT
            )
        """)
        cur.execute("PRAGMA table_info(departments)")
        cols = {r[1] for r in cur.fetchall()}
        if "head_user_id" not in cols:
            try:
                cur.execute("ALTER TABLE departments ADD COLUMN head_user_id INTEGER")
            except Exception:
                pass
        cur.execute("CREATE INDEX IF NOT EXISTS idx_departments_head_user ON departments(head_user_id)")
        conn.commit()