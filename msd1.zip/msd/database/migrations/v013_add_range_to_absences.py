"""
v013: إضافة start_date / end_date إلى جدول الغياب (إن لم تكن موجودة).
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(absences)")
        cols = {r[1] for r in cur.fetchall()}
        if "start_date" not in cols:
            cur.execute("ALTER TABLE absences ADD COLUMN start_date TEXT")
        if "end_date" not in cols:
            cur.execute("ALTER TABLE absences ADD COLUMN end_date TEXT")
        # ملء القيم القديمة إن وُجد عمود date
        if "date" in cols:
            cur.execute("""
                UPDATE absences
                   SET start_date = COALESCE(start_date, date),
                       end_date   = COALESCE(end_date, date)
            """)
        conn.commit()