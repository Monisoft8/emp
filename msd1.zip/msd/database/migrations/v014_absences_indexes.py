"""
v014: فهارس لتحسين تقارير الغياب
"""
from msd.database.connection import get_conn

def up():
    with get_conn() as conn:
        cur = conn.cursor()
        # فهرس على employee_id + start_date (أو date)
        cur.execute("PRAGMA table_info(absences)")
        cols = {r[1] for r in cur.fetchall()}
        if "start_date" in cols:
            cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_employee_start ON absences(employee_id, start_date)")
            cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_range ON absences(start_date, end_date)")
        elif "date" in cols:
            cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_employee_date ON absences(employee_id, date)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_type ON absences(type)")
        conn.commit()