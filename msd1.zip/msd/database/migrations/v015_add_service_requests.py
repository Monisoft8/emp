"""
Migration: Create service_requests table for administrative employee requests.
"""

def apply(conn):
    cur = conn.cursor()
    # إنشاء الجدول
    cur.execute("""
        CREATE TABLE IF NOT EXISTS service_requests (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          request_type TEXT NOT NULL,            -- 'CERT' أو 'SALARY'
          status TEXT NOT NULL DEFAULT 'new',    -- new | preparing | ready | delivered | cancelled
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
            notes TEXT,
          FOREIGN KEY (employee_id) REFERENCES employees(id)
        )
    """)
    # فهرس حسب الحالة
    cur.execute("""
        CREATE INDEX IF NOT EXISTS idx_service_requests_status
        ON service_requests(status)
    """)
    conn.commit()