import os, sqlite3

DB = os.environ.get("DATABASE_PATH","employees.db")
con = sqlite3.connect(DB)
cur = con.cursor()

def col_exists(table,col):
    info = cur.execute(f"PRAGMA table_info({table})").fetchall()
    return any(r[1]==col for r in info)

def table_exists(name):
    r=cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    return bool(r)

print(f"[MIGRATE] DB = {DB}")

# users
if not table_exists("users"):
    cur.execute("""
      CREATE TABLE users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'employee'
      )
    """)
    print("+ created users")

for add_col, ddl in [
    ("department_id","INTEGER"),
    ("telegram_chat_id","TEXT"),
    ("employee_id","INTEGER")
]:
    if not col_exists("users", add_col):
        cur.execute(f"ALTER TABLE users ADD COLUMN {add_col} {ddl}")
        print(f"+ users.{add_col}")

# employees
if not table_exists("employees"):
    cur.execute("""
      CREATE TABLE employees(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        serial_number TEXT,
        name TEXT NOT NULL,
        national_id TEXT,
        department_id INTEGER,
        job_grade TEXT,
        hiring_date TEXT,
        grade_date TEXT,
        bonus REAL DEFAULT 0,
        annual_balance REAL,
        emergency_balance REAL,
        vacation_balance REAL,
        work_days TEXT,
        status TEXT DEFAULT 'active',
        tg_chat_id TEXT
      )
    """)
    print("+ created employees")

for col,ddl in [
    ("annual_balance","REAL"),
    ("emergency_balance","REAL"),
    ("vacation_balance","REAL"),
    ("work_days","TEXT"),
    ("status","TEXT"),
    ("tg_chat_id","TEXT")
]:
    if not col_exists("employees", col):
        cur.execute(f"ALTER TABLE employees ADD COLUMN {col} {ddl}")
        print(f"+ employees.{col}")

# departments
if not table_exists("departments"):
    cur.execute("""
      CREATE TABLE departments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        department_head_id INTEGER
      )
    """)
    print("+ created departments")
elif not col_exists("departments","department_head_id"):
    cur.execute("ALTER TABLE departments ADD COLUMN department_head_id INTEGER")
    print("+ departments.department_head_id")

# vacation_types
if not table_exists("vacation_types"):
    cur.execute("""
      CREATE TABLE vacation_types(
        code TEXT PRIMARY KEY,
        name_ar TEXT,
        fixed_duration INTEGER,
        max_per_request INTEGER,
        requires_relation INTEGER DEFAULT 0,
        affects_annual_balance INTEGER DEFAULT 0,
        affects_emergency_balance INTEGER DEFAULT 0
      )
    """)
    print("+ created vacation_types")
    # Insert minimal seeds
    cur.executemany("""
      INSERT INTO vacation_types(code,name_ar,fixed_duration,max_per_request,requires_relation,affects_annual_balance,affects_emergency_balance)
      VALUES (?,?,?,?,?,?,?)
    """, [
        ("annual","سنوية", None, 30, 0,1,0),
        ("emergency","طارئة", None, 7, 0,0,1),
        ("marriage","زواج", 5, 5, 0,0,0),
        ("death","وفاة", 3, 3, 1,0,0)
    ])
    print("+ seeded vacation_types (أساسية)")

# vacation_requests
if not table_exists("vacation_requests"):
    cur.execute("""
      CREATE TABLE vacation_requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        type_code TEXT NOT NULL,
        relation TEXT,
        start_date TEXT NOT NULL,
        end_date TEXT NOT NULL,
        requested_days INTEGER NOT NULL,
        status TEXT NOT NULL,
        rejection_reason TEXT,
        notes TEXT,
        created_at TEXT NOT NULL
      )
    """)
    print("+ created vacation_requests")

# vacation_history
if not table_exists("vacation_history"):
    cur.execute("""
      CREATE TABLE vacation_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vacation_id INTEGER NOT NULL,
        action TEXT,
        from_status TEXT,
        to_status TEXT,
        actor_id INTEGER,
        actor_role TEXT,
        note TEXT,
        created_at TEXT NOT NULL
      )
    """)
    print("+ created vacation_history")

# absences
if not table_exists("absences"):
    cur.execute("""
      CREATE TABLE absences(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        type TEXT NOT NULL,           -- absence | late | early_leave
        start_date TEXT NOT NULL,
        end_date TEXT,
        duration INTEGER,
        notes TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
      )
    """)
    print("+ created absences")

# service_requests (مختصر لو مفقود)
if not table_exists("service_requests"):
    cur.execute("""
      CREATE TABLE service_requests(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        request_type TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'new',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        notes TEXT
      )
    """)
    print("+ created service_requests")

# فهارس أساسية
try:
    cur.execute("CREATE INDEX IF NOT EXISTS idx_vac_req_emp ON vacation_requests(employee_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_absences_emp ON absences(employee_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_employees_dept ON employees(department_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_departments_head ON departments(department_head_id)")
except Exception as e:
    print("Index issue:", e)

con.commit()
con.close()
print("[MIGRATE] Done.")