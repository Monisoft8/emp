from flask import Blueprint, jsonify
from flask_login import login_required
from msd.auth.security import roles_required
from msd.departments.service import list_departments

departments_api = Blueprint("departments_api", __name__)

@departments_api.get("/departments")
@login_required
def get_departments():
    return jsonify(list_departments())