from msd.database.connection import get_conn

def list_departments():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id, name, head_employee_id FROM departments ORDER BY name")
        return [dict(r) for r in cur.fetchall()]