# msd/employees/__init__.py
"""Employees package for MSD Employee Management System"""