from flask import Blueprint, jsonify
from flask_login import login_required
from msd.employees.service import list_employees, get_employee, get_balances

employees_api = Blueprint("employees_api", __name__)

@employees_api.get("/employees")
@login_required
def employees_list():
    return jsonify(list_employees())

@employees_api.get("/employees/<int:emp_id>")
@login_required
def employee_detail(emp_id):
    emp = get_employee(emp_id)
    if not emp:
        return jsonify({"error": "not found"}), 404
    return jsonify(emp)

@employees_api.get("/employees/<int:emp_id>/balances")
@login_required
def employee_balances(emp_id):
    b = get_balances(emp_id)
    if not b:
        return jsonify({"error": "not found"}), 404
    return jsonify(b)