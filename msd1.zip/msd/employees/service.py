from msd.database.connection import get_conn

EMP_COLUMNS = """
id, serial_number, name, national_id, department_id,
job_grade, hiring_date, grade_date, bonus,
annual_balance, emergency_balance, work_days, gender
""".strip()

def list_employees():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT {EMP_COLUMNS} FROM employees ORDER BY name")
        return [dict(r) for r in cur.fetchall()]

def get_employee(emp_id: int):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(f"SELECT {EMP_COLUMNS} FROM employees WHERE id=?", (emp_id,))
        row = cur.fetchone()
        return dict(row) if row else None

def get_balances(emp_id: int):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT annual_balance, emergency_balance FROM employees WHERE id=?", (emp_id,))
        row = cur.fetchone()
        if row:
            return {"annual_balance": row["annual_balance"], "emergency_balance": row["emergency_balance"]}
        return None