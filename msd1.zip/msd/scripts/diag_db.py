import os, sqlite3, textwrap
DB=os.environ.get("DATABASE_PATH","employees.db")
con=sqlite3.connect(DB)
con.row_factory=sqlite3.Row
print(f"[DIAG] Using DB: {DB}")
tables=[r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
print("Tables:", tables)
for t in tables:
    print(f"\n-- {t}")
    for r in con.execute(f"PRAGMA table_info({t})"):
        print("  ", r[1], r[2])
print("\nCounts:")
for t in tables:
    try:
        c=con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
        print(f"  {t}: {c}")
    except Exception as e:
        print(f"  {t}: error {e}")
con.close()