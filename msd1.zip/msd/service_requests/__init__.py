# حزمة طلبات الخدمة (إفادة / شهادة مرتب)
# تُستخدم من خلال:
# - msd.service_requests.service (منطق الأعمال)
# - msd.service_requests.routes (REST API)
# - msd.service_requests.views  (واجهات HTML)