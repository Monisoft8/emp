from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from msd.service_requests import service as svc

service_requests_api = Blueprint("service_requests_api", __name__)

def _ensure_manager():
    return current_user.role in ("manager", "admin")

@service_requests_api.get("/service-requests")
@login_required
def list_requests():
    if not _ensure_manager():
        return jsonify({"error":"forbidden"}), 403
    status = request.args.get("status")
    try:
        data = svc.list_requests(status=status)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error":str(e)}), 400

@service_requests_api.get("/service-requests/<int:rid>")
@login_required
def get_request(rid):
    if not _ensure_manager():
        return jsonify({"error":"forbidden"}), 403
    r = svc.get_request(rid)
    if not r:
        return jsonify({"error":"not found"}), 404
    return jsonify(r)

@service_requests_api.post("/service-requests/<int:rid>/status")
@login_required
def update_status(rid):
    if not _ensure_manager():
        return jsonify({"error":"forbidden"}), 403
    payload = request.get_json(silent=True) or {}
    status = payload.get("status")
    notes = payload.get("notes")
    try:
        result = svc.update_status(rid, status, notes=notes)
        return jsonify({"message":"updated", "result": result})
    except Exception as e:
        return jsonify({"error":str(e)}), 400