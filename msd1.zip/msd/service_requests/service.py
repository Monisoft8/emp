import os
from datetime import datetime
from typing import Optional, Dict
from msd.database.connection import get_conn

VALID_TYPES = {"CERT", "SALARY"}
VALID_STATUS = {"new", "preparing", "ready", "delivered", "cancelled"}

TYPE_LABELS_AR = {
    "CERT": "إفادة",
    "SALARY": "شهادة مرتب"
}

STATUS_MESSAGES_AR = {
    "preparing": "يتم الآن تجهيز طلبك ({type_label}).",
    "ready": "طلبك ({type_label}) جاهز للاستلام من الإدارة.",
    "delivered": "تم تسليم طلبك ({type_label}). شكراً لك.",
    "cancelled": "تم إلغاء طلبك ({type_label}). لمزيد من المعلومات تواصل مع الإدارة."
}

TELEGRAM_ENABLED = os.getenv("TELEGRAM_NOTIFICATIONS_ENABLED", "1") == "1"
BOT_TOKEN = os.getenv("BOT_TOKEN")

try:
    if BOT_TOKEN and TELEGRAM_ENABLED:
        from telegram import Bot
        _bot_instance: Optional[Bot] = Bot(BOT_TOKEN)
    else:
        _bot_instance = None
except Exception:
    _bot_instance = None


def _now():
    return datetime.utcnow().isoformat(timespec="seconds")


def create_request(employee_id: int, request_type: str):
    if request_type not in VALID_TYPES:
        raise ValueError("نوع طلب غير مدعوم")
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO service_requests (employee_id, request_type, status, created_at, updated_at)
            VALUES (?, ?, 'new', ?, ?)
        """, (employee_id, request_type, _now(), _now()))
        rid = cur.lastrowid
        conn.commit()
        return rid


def list_requests(status=None, limit=300):
    clauses = []
    params = []
    if status:
        clauses.append("sr.status=?")
        params.append(status)
    where_sql = ("WHERE " + " AND ".join(clauses)) if clauses else ""
    sql = f"""
        SELECT sr.id, sr.employee_id, e.name AS employee_name,
               sr.request_type, sr.status, sr.created_at, sr.updated_at, sr.notes
          FROM service_requests sr
          LEFT JOIN employees e ON e.id=sr.employee_id
          {where_sql}
         ORDER BY sr.id DESC
         LIMIT ?
    """
    params.append(limit)
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]


def list_employee_requests(employee_id: int, limit=20):
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT id, request_type, status, created_at, updated_at, notes
              FROM service_requests
             WHERE employee_id=?
             ORDER BY id DESC
             LIMIT ?
        """, (employee_id, limit))
        return [dict(r) for r in cur.fetchall()]


def get_request(request_id: int) -> Optional[Dict]:
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT sr.id, sr.employee_id, e.name AS employee_name,
                   sr.request_type, sr.status, sr.created_at, sr.updated_at, sr.notes
              FROM service_requests sr
              LEFT JOIN employees e ON e.id=sr.employee_id
             WHERE sr.id=?
        """, (request_id,))
        r = cur.fetchone()
        return dict(r) if r else None


def _get_employee_chat_id(employee_id: int) -> Optional[int]:
    with get_conn() as conn:
        cur = conn.cursor()
        try:
            cur.execute("SELECT tg_chat_id FROM employees WHERE id=?", (employee_id,))
            row = cur.fetchone()
            if not row:
                return None
            chat_id = row[0]
            if not chat_id:
                return None
            return int(chat_id)
        except Exception:
            return None


def _notify_employee_status(employee_id: int, request_type: str, new_status: str):
    if not TELEGRAM_ENABLED or not _bot_instance:
        return False
    if new_status not in STATUS_MESSAGES_AR:
        return False
    chat_id = _get_employee_chat_id(employee_id)
    if not chat_id:
        return False
    type_label = TYPE_LABELS_AR.get(request_type, request_type)
    text = STATUS_MESSAGES_AR[new_status].format(type_label=type_label)
    try:
        _bot_instance.send_message(chat_id=chat_id, text=text)
        return True
    except Exception:
        return False


def update_status(request_id: int, new_status: str, notes: str = None):
    if new_status not in VALID_STATUS:
        raise ValueError("حالة غير مدعومة")
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("""
            SELECT employee_id, request_type, status
              FROM service_requests
             WHERE id=?
        """, (request_id,))
        row = cur.fetchone()
        if not row:
            raise ValueError("الطلب غير موجود")
        employee_id, request_type, old_status = row
        cur.execute("""
            UPDATE service_requests
               SET status=?, updated_at=?, notes=COALESCE(?, notes)
             WHERE id=?
        """, (new_status, _now(), notes, request_id))
        conn.commit()
    try:
        _notify_employee_status(employee_id, request_type, new_status)
    except Exception:
        pass
    return {
        "id": request_id,
        "old_status": old_status,
        "new_status": new_status,
        "employee_id": employee_id,
        "request_type": request_type
    }