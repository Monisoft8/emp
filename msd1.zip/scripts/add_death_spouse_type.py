import os, sqlite3

DB = os.environ.get("DATABASE_PATH","employees.db")
con = sqlite3.connect(DB)
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS vacation_types(
  code TEXT PRIMARY KEY,
  name_ar TEXT,
  fixed_duration INTEGER,
  max_per_request INTEGER,
  requires_relation INTEGER DEFAULT 0,
  affects_annual_balance INTEGER DEFAULT 0,
  affects_emergency_balance INTEGER DEFAULT 0
)
""")

row = cur.execute("SELECT code FROM vacation_types WHERE code='death_spouse'").fetchone()
if not row:
    cur.execute("""
      INSERT INTO vacation_types(code,name_ar,fixed_duration,max_per_request,
                                 requires_relation,affects_annual_balance,affects_emergency_balance)
      VALUES (?,?,?,?,?,?,?)
    """, ("death_spouse","وفاة الزوج",130,130,1,0,0))
    print("[OK] Added death_spouse (وفاة الزوج)")
else:
    print("[INFO] death_spouse already exists")

con.commit()
con.close()