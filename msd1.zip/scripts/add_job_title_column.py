import os, sqlite3
DB = os.environ.get("DATABASE_PATH","employees.db")
con = sqlite3.connect(DB)
cur = con.cursor()
cols = {r[1] for r in cur.execute("PRAGMA table_info(employees)")}
if "job_title" not in cols:
    cur.execute("ALTER TABLE employees ADD COLUMN job_title TEXT")
    cur.execute("UPDATE employees SET job_title = job_grade WHERE job_grade IS NOT NULL")
    con.commit()
    print("[OK] job_title column added and populated.")
else:
    print("[INFO] job_title already exists.")
con.close()