import sqlite3
from passlib.hash import bcrypt

db_path = "employees.db"  # عدّل المسار إذا مختلف
conn = sqlite3.connect(db_path)
conn.execute("""
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user'
)
""")
password_hash = bcrypt.hash("admin123")
conn.execute("INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?, ?, ?)",
             ("admin", password_hash, "manager"))
conn.commit()
conn.close()
print("User admin/admin123 created (or already exists).")