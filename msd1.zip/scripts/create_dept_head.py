import argparse
from msd import create_app
from msd.auth.service import create_user_if_not_exists

def main():
    parser = argparse.ArgumentParser(description="إنشاء/تحديث مستخدم رئيس قسم")
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--department", required=True, type=int)
    parser.add_argument("--telegram", required=False, help="chat_id للتلغرام (اختياري)")
    args = parser.parse_args()

    # تأكد من تهيئة التطبيق (لتحميل الاتصال وقيم التهيئة)
    app = create_app()
    with app.app_context():
        user_id = create_user_if_not_exists(
            username=args.username,
            password=args.password,
            role="department_head",
            department_id=args.department,
            telegram_chat_id=args.telegram
        )
        print(f"✅ تم إنشاء/تحديث المستخدم (id={user_id}) كرئيس قسم قسم={args.department}")

if __name__ == "__main__":
    main()