import os, sys, datetime
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from msd.database.connection import get_conn

def main():
    with get_conn() as conn:
        cur = conn.cursor()
        cur.execute("SELECT id FROM employees WHERE department_id=1 LIMIT 1")
        row = cur.fetchone()
        if not row:
            print("❌ لا يوجد موظف في department_id=1. عدّل قسم موظف أولاً.")
            return
        emp_id = row[0]
        today = datetime.date.today().isoformat()
        cur.execute("""
            INSERT INTO vacation_requests
            (employee_id,type_code,relation,start_date,end_date,requested_days,status,notes,created_at)
            VALUES(?,?,?,?,?,?,?,?,?)
        """, (emp_id,'ANNUAL',None,today,today,1,'pending_dept','طلب تجريبي',
              datetime.datetime.utcnow().isoformat()))
        conn.commit()
        print(f"✅ أُنشئ طلب تجريبي (employee_id={emp_id})")

if __name__ == "__main__":
    main()