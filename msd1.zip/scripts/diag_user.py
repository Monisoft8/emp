import os, sys, sqlite3

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

DB_PATH = os.path.join(BASE_DIR, "employees.db")

def main(username):
    c = sqlite3.connect(DB_PATH)
    cur = c.cursor()
    cur.execute("SELECT id, username, password_hash, role, department_id FROM users WHERE username=?", (username,))
    row = cur.fetchone()
    if not row:
        print("❌ المستخدم غير موجود")
    else:
        print("✅ صف المستخدم:", row)
        print("hash starts with:", row[2][:15])
        if row[2].startswith("$2"):
            print("طريقة التشفير: bcrypt (متوقع)")
        elif row[2].startswith("pbkdf2:"):
            print("طريقة التشفير: pbkdf2 (قديمة ولكن مدعومة)")
        else:
            print("تنسيق غير معلوم للهاش")
    c.close()

if __name__ == "__main__":
    if len(sys.argv)<2:
        print("استخدم: python scripts/diag_user.py USERNAME")
    else:
        main(sys.argv[1])