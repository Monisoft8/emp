import os, sys, sqlite3, argparse

DB_PATH = "employees.db"

def main():
    p = argparse.ArgumentParser(description="تعديل دور مستخدم")
    p.add_argument("--username", required=True)
    p.add_argument("--role", required=True, choices=["admin","manager","department_head","user"])
    p.add_argument("--department", type=int, help="department_id (اختياري)")
    args = p.parse_args()

    if not os.path.exists(DB_PATH):
        print("❌ لم يتم العثور على قاعدة البيانات:", DB_PATH)
        sys.exit(1)

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id, role, department_id FROM users WHERE username=?", (args.username,))
    row = cur.fetchone()
    if not row:
        print("❌ المستخدم غير موجود")
        conn.close()
        sys.exit(1)

    updates = ["role=?"]
    params = [args.role]
    if args.department is not None:
        updates.append("department_id=?")
        params.append(args.department)
    params.append(args.username)
    cur.execute(f"UPDATE users SET {', '.join(updates)} WHERE username=?", params)
    conn.commit()
    cur.execute("SELECT id, username, role, department_id FROM users WHERE username=?", (args.username,))
    print("✅ بعد التحديث:", cur.fetchone())
    conn.close()

if __name__ == "__main__":
    main()