import os, sqlite3, sys
from datetime import datetime

DB = os.environ.get("DATABASE_PATH","employees.db")
XLSX = len(sys.argv)>1 and sys.argv[1] or "employees_data.xlsx"

try:
    import openpyxl
except ImportError:
    print("Install openpyxl: pip install openpyxl")
    sys.exit(1)

ORDER = [
    "serial_number","name","national_id","hiring_date","job_grade",
    "bonus","grade_date","vacation_balance","department","work_days"
]

def ensure_dep(conn, name_or_id):
    if not name_or_id or str(name_or_id).strip()=="":
        return None
    cur = conn.cursor()
    try:
        did = int(str(name_or_id))
        r = cur.execute("SELECT id FROM departments WHERE id=?", (did,)).fetchone()
        if r: return did
    except:
        pass
    name = str(name_or_id).strip()
    r = cur.execute("SELECT id FROM departments WHERE name=?", (name,)).fetchone()
    if r: return r[0]
    cur.execute("INSERT INTO departments(name) VALUES(?)",(name,))
    return cur.lastrowid

def run():
    if not os.path.exists(XLSX):
        print("File not found:", XLSX); return
    wb = openpyxl.load_workbook(XLSX)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        print("Empty file"); return
    # كشف ترويسة
    start = 0
    header = [str(c).strip().lower() if c else "" for c in rows[0]]
    if "name" in header and "serial_number" in header:
        start = 1
    con = sqlite3.connect(DB)
    ins = 0; skip=0
    try:
        cur = con.cursor()
        for r in rows[start:]:
            if r is None: continue
            row = list(r)+[None]*(len(ORDER)-len(r))
            name = (row[1] or "").strip()
            if not name:
                skip+=1
                continue
            serial = (row[0] or "") and str(row[0]).strip()
            national = (row[2] or "") and str(row[2]).strip()
            hiring_date = row[3] and str(row[3]).split()[0]
            job_grade = row[4] and str(row[4]).strip()
            bonus = 0
            if row[5] not in (None,""):
                try: bonus = float(row[5])
                except: bonus = 0
            grade_date = row[6] and str(row[6]).split()[0]
            vac_balance = 0
            if row[7] not in (None,""):
                try: vac_balance = float(row[7])
                except: pass
            department_ref = row[8]
            work_days = row[9] and str(row[9]).strip()
            dep_id = ensure_dep(con, department_ref)
            cur.execute("""
              INSERT INTO employees(serial_number,name,national_id,department_id,
                                    job_grade,hiring_date,grade_date,bonus,
                                    annual_balance,emergency_balance,vacation_balance,
                                    work_days,status)
              VALUES (?,?,?,?,?,?,?,?,?,?,?,?,'active')
            """,(serial,name,national,dep_id,job_grade,hiring_date,grade_date,bonus,
                 vac_balance,0,vac_balance,work_days))
            ins+=1
        con.commit()
        print(f"Imported {ins} (skipped {skip})")
    finally:
        con.close()

if __name__=="__main__":
    run()