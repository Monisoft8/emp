import os, sqlite3

DB = os.environ.get("DATABASE_PATH", "employees.db")
con = sqlite3.connect(DB)
cur = con.cursor()

# vacation_types
cur.execute("""
CREATE TABLE IF NOT EXISTS vacation_types(
    code TEXT PRIMARY KEY,
    name_ar TEXT,
    fixed_duration INTEGER,
    max_per_request INTEGER,
    requires_relation INTEGER DEFAULT 0,
    affects_annual_balance INTEGER DEFAULT 0,
    affects_emergency_balance INTEGER DEFAULT 0
)
""")
cnt = cur.execute("SELECT COUNT(*) FROM vacation_types").fetchone()[0]
if cnt == 0:
    seed = [
        ("annual","سنوية",None,90,0,1,0),
        ("emergency","طارئة",None,3,0,0,1),
        ("death1","وفاة (درجة أولى)",7,7,1,0,0),
        ("death2","وفاة (درجة ثانية)",3,3,1,0,0),
        ("marriage","زواج",14,14,0,0,0),
        ("hajj","حج",20,20,0,0,0),
        ("birth_single","وضع (عادي)",98,98,0,0,0),
        ("birth_twins","وضع (توأم)",112,112,0,0,0),
        ("sick","مرضية",None,30,0,0,0),
    ]
    cur.executemany("""
      INSERT INTO vacation_types(code,name_ar,fixed_duration,max_per_request,
                                 requires_relation,affects_annual_balance,affects_emergency_balance)
      VALUES (?,?,?,?,?,?,?)
    """, seed)
    print("[SEED] vacation_types inserted")

# تأكد من أعمدة departments
info = {r[1] for r in cur.execute("PRAGMA table_info(departments)")}
if "head_password" not in info:
    cur.execute("ALTER TABLE departments ADD COLUMN head_password TEXT")
if "department_head_employee_id" not in info:
    cur.execute("ALTER TABLE departments ADD COLUMN department_head_employee_id INTEGER")

con.commit()
con.close()
print("[OK] Migration done.")