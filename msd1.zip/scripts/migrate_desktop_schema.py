import os, sqlite3

DB = os.environ.get("DATABASE_PATH", "employees.db")
print(f"[MIGRATE] Using DB: {DB}")
con = sqlite3.connect(DB)
cur = con.cursor()

def table_exists(t):
    return cur.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone() is not None

def col_exists(t, c):
    try:
        cols = [r[1] for r in cur.execute(f"PRAGMA table_info({t})")]
        return c in cols
    except:
        return False

# 1) employees
if not table_exists("employees"):
    cur.execute("""
        CREATE TABLE employees(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          serial_number TEXT,
          name TEXT NOT NULL,
          national_id TEXT,
          department TEXT,
          job_grade TEXT,
          hiring_date TEXT,
          grade_date TEXT,
            bonus REAL DEFAULT 0,
          vacation_balance REAL DEFAULT 0,
          emergency_vacation_balance REAL DEFAULT 0,
          work_days TEXT,
          status TEXT DEFAULT 'active'
        )
    """)
    print("+ created employees")
else:
    for col, ddl in [
        ("department","TEXT"),
        ("vacation_balance","REAL DEFAULT 0"),
        ("emergency_vacation_balance","REAL DEFAULT 0"),
        ("work_days","TEXT"),
        ("status","TEXT DEFAULT 'active'")
    ]:
        if not col_exists("employees", col):
            cur.execute(f"ALTER TABLE employees ADD COLUMN {col} {ddl}")
            print(f"+ employees.{col}")

# 2) departments
if not table_exists("departments"):
    cur.execute("""
        CREATE TABLE departments(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL,
          head_password TEXT,
          department_head_employee_id INTEGER
        )
    """)
    print("+ created departments")
else:
    for col, ddl in [
        ("head_password","TEXT"),
        ("department_head_employee_id","INTEGER")
    ]:
        if not col_exists("departments", col):
            cur.execute(f"ALTER TABLE departments ADD COLUMN {col} {ddl}")
            print(f"+ departments.{col}")

# 3) vacations
if not table_exists("vacations"):
    cur.execute("""
        CREATE TABLE vacations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          type TEXT NOT NULL,
          relation TEXT,
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          duration INTEGER NOT NULL,
          notes TEXT,
          status TEXT NOT NULL DEFAULT 'تحت الإجراء',
          dept_approval TEXT NOT NULL DEFAULT 'تحت الإجراء',
          dept_approver INTEGER,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("+ created vacations")
else:
    # تأكد من الحقول اللازمة
    for col, ddl in [
        ("dept_approval","TEXT NOT NULL DEFAULT 'تحت الإجراء'"),
        ("dept_approver","INTEGER"),
        ("relation","TEXT"),
        ("notes","TEXT")
    ]:
        if not col_exists("vacations", col):
            cur.execute(f"ALTER TABLE vacations ADD COLUMN {col} {ddl}")
            print(f"+ vacations.{col}")

# 4) absences
if not table_exists("absences"):
    cur.execute("""
        CREATE TABLE absences(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          employee_id INTEGER NOT NULL,
          date TEXT NOT NULL,
          type TEXT NOT NULL,
          duration INTEGER,
          notes TEXT,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("+ created absences")

# 5) audit_log (مطلوب في absences.py عند إدراج)
if not table_exists("audit_log"):
    cur.execute("""
        CREATE TABLE audit_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          action TEXT,
          table_name TEXT,
          record_id INTEGER,
          changes TEXT,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    print("+ created audit_log")

# فهارس بسيطة
try:
    cur.execute("CREATE INDEX IF NOT EXISTS idx_vac_emp ON vacations(employee_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_abs_emp ON absences(employee_id)")
    cur.execute("CREATE INDEX IF NOT EXISTS idx_emp_dept ON employees(department)")
except Exception as e:
    print("Index error:", e)

con.commit()
con.close()
print("[MIGRATE] Done.")