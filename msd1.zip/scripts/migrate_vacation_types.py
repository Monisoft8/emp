import os, sqlite3

DB = os.environ.get("DATABASE_PATH", "employees.db")
con = sqlite3.connect(DB)
cur = con.cursor()

# vacation_types table
cur.execute("""
CREATE TABLE IF NOT EXISTS vacation_types(
  code TEXT PRIMARY KEY,
  name_ar TEXT NOT NULL,
  fixed_duration INTEGER,
  max_per_request INTEGER,
  requires_relation INTEGER DEFAULT 0,
  affects_annual_balance INTEGER DEFAULT 0,
  affects_emergency_balance INTEGER DEFAULT 0
)
""")

seed = [
    # code, name_ar, fixed_duration, max_per_request, requires_relation, affects_annual, affects_emergency
    ("annual", "سنوية", None, 90, 0, 1, 0),
    ("emergency", "طارئة", None, 3, 0, 0, 1),
    ("death1", "وفاة درجة أولى", 7, 7, 1, 0, 0),
    ("death2", "وفاة درجة ثانية", 3, 3, 1, 0, 0),
    ("hajj", "حج", 20, 20, 0, 0, 0),
    ("marriage", "زواج", 14, 14, 0, 0, 0),
    ("birth_single", "وضع (عادي)", 98, 98, 0, 0, 0),
    ("birth_twins", "وضع (توأم)", 112, 112, 0, 0, 0),
    ("sick", "مرضية", None, 30, 0, 0, 0),
]

existing = {r[0] for r in cur.execute("SELECT code FROM vacation_types")}
for row in seed:
    if row[0] not in existing:
        cur.execute("""INSERT INTO vacation_types
          (code,name_ar,fixed_duration,max_per_request,requires_relation,affects_annual_balance,affects_emergency_balance)
          VALUES (?,?,?,?,?,?,?)""", row)

# vacation_requests table
cur.execute("""
CREATE TABLE IF NOT EXISTS vacation_requests(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id INTEGER NOT NULL,
  type_code TEXT NOT NULL,
  relation TEXT,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  requested_days INTEGER NOT NULL,
  status TEXT NOT NULL,
  rejection_reason TEXT,
  notes TEXT,
  created_at TEXT NOT NULL
)
""")

# vacation_history table
cur.execute("""
CREATE TABLE IF NOT EXISTS vacation_history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vacation_id INTEGER NOT NULL,
  action TEXT,
  from_status TEXT,
  to_status TEXT,
  actor_id INTEGER,
  actor_role TEXT,
  note TEXT,
  created_at TEXT NOT NULL
)
""")

# أعمدة الأرصدة في employees
info = {r[1] for r in cur.execute("PRAGMA table_info(employees)")}
changes = False
if "vacation_balance" not in info:
    cur.execute("ALTER TABLE employees ADD COLUMN vacation_balance REAL DEFAULT 0")
    changes = True
if "emergency_vacation_balance" not in info and "emergency_balance" not in info:
    # نضيف واحد قياسي
    cur.execute("ALTER TABLE employees ADD COLUMN emergency_vacation_balance REAL DEFAULT 0")
    changes = True
if changes:
    print("[INFO] Added missing balance columns.")

con.commit()
con.close()
print("[OK] vacation types migration done.")