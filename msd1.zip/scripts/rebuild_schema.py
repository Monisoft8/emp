import os, sqlite3, sys, textwrap

DB = os.environ.get("DATABASE_PATH", "employees.db")
if not DB:
    print("DATABASE_PATH not set"); sys.exit(1)

schema_sql = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'employee',
    department_id INTEGER,
    telegram_chat_id TEXT,
    employee_id INTEGER
);

CREATE TABLE IF NOT EXISTS departments(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    department_head_id INTEGER
);

CREATE TABLE IF NOT EXISTS employees(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serial_number TEXT,
    name TEXT NOT NULL,
    national_id TEXT,
    department_id INTEGER,
    job_grade TEXT,
    hiring_date TEXT,
    grade_date TEXT,
    bonus REAL DEFAULT 0,
    annual_balance REAL DEFAULT 0,
    emergency_balance REAL DEFAULT 0,
    vacation_balance REAL DEFAULT 0,
    work_days TEXT,
    status TEXT DEFAULT 'active',
    tg_chat_id TEXT
);

CREATE TABLE IF NOT EXISTS vacation_types(
    code TEXT PRIMARY KEY,
    name_ar TEXT,
    fixed_duration INTEGER,
    max_per_request INTEGER,
    requires_relation INTEGER DEFAULT 0,
    affects_annual_balance INTEGER DEFAULT 0,
    affects_emergency_balance INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS vacation_requests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    type_code TEXT NOT NULL,
    relation TEXT,
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    requested_days INTEGER NOT NULL,
    status TEXT NOT NULL,
    rejection_reason TEXT,
    notes TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vacation_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    vacation_id INTEGER NOT NULL,
    action TEXT,
    from_status TEXT,
    to_status TEXT,
    actor_id INTEGER,
    actor_role TEXT,
    note TEXT,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS absences(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    type TEXT NOT NULL,
    start_date TEXT NOT NULL,
    end_date TEXT,
    duration INTEGER,
    notes TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_requests(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER NOT NULL,
    request_type TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_emp_dept ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_vac_emp ON vacation_requests(employee_id);
CREATE INDEX IF NOT EXISTS idx_abs_emp ON absences(employee_id);
CREATE INDEX IF NOT EXISTS idx_dept_head ON departments(department_head_id);
""".strip()

seed_vac_types = [
    ("annual", "سنوية", None, 30, 0, 1, 0),
    ("emergency", "طارئة", None, 7, 0, 0, 1),
    ("marriage", "زواج", 5, 5, 0, 0, 0),
    ("death", "وفاة", 3, 3, 1, 0, 0)
]

def run():
    fresh = not os.path.exists(DB) or os.path.getsize(DB) < 4096
    con = sqlite3.connect(DB)
    try:
        con.executescript(schema_sql)
        # زرع الأنواع إذا فارغة
        cur = con.execute("SELECT COUNT(*) FROM vacation_types")
        if cur.fetchone()[0] == 0:
            con.executemany("""
              INSERT INTO vacation_types(code,name_ar,fixed_duration,max_per_request,
                                         requires_relation,affects_annual_balance,affects_emergency_balance)
              VALUES (?,?,?,?,?,?,?)
            """, seed_vac_types)
            print("[SEED] added vacation_types")
        con.commit()
        print(f"[OK] Schema ensured at {DB}")
    finally:
        con.close()

if __name__ == "__main__":
    run()