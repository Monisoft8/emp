import os, sys, argparse
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from msd import create_app
from msd.auth.service import update_user_password

def main():
    p = argparse.ArgumentParser(description="تحديث كلمة مرور مستخدم (تحويلها إلى bcrypt)")
    p.add_argument("--username", required=True)
    p.add_argument("--password", required=True)
    args = p.parse_args()
    app = create_app()
    with app.app_context():
        update_user_password(args.username, args.password)
        print(f"✅ تم تحديث كلمة المرور للمستخدم {args.username} (bcrypt)")
if __name__ == "__main__":
    main()